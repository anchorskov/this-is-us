// static/js/events/event-form.js

import { initMap, bindAddressSearch } from './event-map.js';
import { bindPdfPreview, showError, toggleLoading, showSuccess } from './ui-feedback.js';
import { renderPreview } from './preview-renderer.js';
import { submitEvent } from './submit-event.js';
import {
  isValidEmail,
  isValidPhone,
  isFutureDate,
  areRequiredFieldsPresent,
} from './validation-utils.js';

// ——————————————————————————————————————————
// Form state
// ——————————————————————————————————————————
let formDataCache = {};

/**
 * Render the blank form into the DOM and wire up map, preview, and logic.
 * @param {Object} user  Authenticated user object
 */
export function renderForm(user) {
  const container = document.querySelector('#event-form');
  if (!container) return;

  // 1) Inject HTML
  container.innerHTML = getFormHTML();

  // 2) Initialize widgets
  const { setMarker } = initMap();
  bindAddressSearch(setMarker);
  bindPdfPreview();

  // 3) Wire form logic
  bindFormLogic(user);
}

/**
 * HTML template for the form.
 */
function getFormHTML() {
  return `
    <div class="w-100 flex items-center justify-center pa5" style="background-color: #f7f7f7;">
      <div class="w-100 w-90-m w-80-l mw6 pa4 br3 shadow-1 bg-white">
        <h2 class="f3 fw6 tc mb4">Create an Event</h2>
        <form id="eventForm" class="flex flex-column">
          <!-- (all your inputs & buttons here, unchanged) -->
        </form>
        <div id="event-preview" class="dn mt4"></div>
      </div>
    </div>`;
}

/**
 * Wire up preview & submit handling.
 * @param {Object} user
 */
function bindFormLogic(user) {
  const previewBtn = document.querySelector('#previewEvent');
  if (!previewBtn) return;

  previewBtn.addEventListener('click', handlePreview);

  // Delegate confirmSubmit click for dynamic content
  document.addEventListener('click', async (e) => {
    if (e.target && e.target.id === 'confirmSubmit') {
      await handleSubmit();
    }
  });
}

/**
 * Gather, validate, and show preview.
 */
function handlePreview() {
  const $ = id => document.getElementById(id);
  const values = {
    title: $('title').value.trim(),
    datetime: $('datetime').value,
    description: $('description').value.trim(),
    address: $('address').value.trim(),
    sponsor: $('sponsor').value.trim(),
    contactEmail: $('contactEmail').value.trim(),
    contactPhone: $('contactPhone').value.trim(),
    lat: $('lat').value,
    lng: $('lng').value,
    file: $('eventPdf').files[0],
  };

  // Required fields + file
  if (
    !areRequiredFieldsPresent([
      values.title,
      values.datetime,
      values.description,
      values.lat,
      values.lng,
    ]) ||
    !values.file
  ) {
    return showError('Please complete all required fields.');
  }

  // Date & format checks
  const isoDate = new Date(values.datetime).toISOString();
  if (!isFutureDate(isoDate)) {
    return showError('Date must be in the future.');
  }
  if (values.contactEmail && !isValidEmail(values.contactEmail)) {
    return showError('Invalid email.');
  }
  if (values.contactPhone && !isValidPhone(values.contactPhone)) {
    return showError('Invalid phone.');
  }

  // Store for submission
  formDataCache = { ...values, datetime: isoDate };
  renderPreview(formDataCache);

  // Hide the form, show the preview
  document.querySelector('#eventForm').style.display = 'none';
  document.querySelector('#event-preview').style.display = 'block';
}

/**
 * Send the event to the Worker and show feedback.
 */
async function handleSubmit() {
  toggleLoading(true, '#confirmSubmit', 'Submitting…');

  const { ok, message } = await submitEvent(formDataCache);

  toggleLoading(false, '#confirmSubmit', '✅ Confirm & Submit');
  if (ok) {
    showSuccess('🎉 Event has been scheduled!');
    resetForm();
  } else {
    showError(message);
  }
}

/**
 * Reset form & preview for a new entry.
 */
function resetForm() {
  const form = document.querySelector('#eventForm');
  const preview = document.querySelector('#event-preview');
  if (form) {
    form.reset();
    form.style.display = 'block';
  }
  if (preview) {
    preview.innerHTML = '';
    preview.style.display = 'none';
  }
}

