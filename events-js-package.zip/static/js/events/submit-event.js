// static/js/events/submit-event.js

// ——————————————————————————————————————————
// Configuration
// ——————————————————————————————————————————
const API_URL = window.EVENTS_API_URL || "/api/events/create"; 
// → you can override window.EVENTS_API_URL in your template
//    so we switch endpoints between dev, staging, prod.

// ——————————————————————————————————————————
// Public API
// ——————————————————————————————————————————
/**
 * Submit event data to our Worker.
 * @param {Object} payload  Plain JS object (no FormData).
 * @returns {Promise<{ok: boolean, message: string}>}
 */
export async function submitEvent(payload) {
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const body = await res.json();
    return {
      ok: res.ok,
      message: body.message || (res.ok ? "Event submitted." : "Submission failed."),
    };
  } catch (error) {
    // Network or unexpected error
    return { ok: false, message: error.message };
  }
}
