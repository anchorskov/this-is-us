console.log("🔥 Auth script has been loaded and is running.");

if (typeof firebase === "undefined" || typeof firebaseui === "undefined") {
  console.error("❌ Firebase or FirebaseUI not loaded.");
} else {
  const auth = firebase.auth();

  const persistence = location.hostname === "localhost"
    ? firebase.auth.Auth.Persistence.SESSION
    : firebase.auth.Auth.Persistence.LOCAL;

  auth.setPersistence(persistence)
    .then(() => console.log("🔒 Auth persistence set:", persistence))
    .catch(err => console.error("❌ Failed to set persistence:", err));

  function setupLogoutButton() {
    const logoutBtn = document.getElementById("logout-btn");
    if (!logoutBtn) return;

    auth.onAuthStateChanged(user => {
      console.log("🔍 Auth observer triggered");
      console.log("👤 Firebase currentUser:", firebase.auth().currentUser);
      console.log("👤 Callback user:", user);

      if (user) {
        logoutBtn.style.display = "inline-block";
        logoutBtn.onclick = () => {
          auth.signOut()
            .then(() => {
              alert("Logged out.");
              location.reload();
            })
            .catch(err => console.error("Logout error:", err));
        };
      } else {
        logoutBtn.style.display = "none";
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    console.log("🧠 DOM ready → running firebase-auth.js setup...");
    setupLogoutButton(); // Only handles logout UI
  });
}
