---
title: "Events"
---

## Upcoming Events

### 🎓 Voices for Democracy Workshop  
🗓 **April 12 2025 – 11:00 AM to 7:00 PM**  
🗓 **This is US Townhall** 
🗓 **Eansville Community Center**  

Empower your voice in democracy through dialogue and action.

---

### 💬 Courageous Conversations Series  
🗓 **June 1, 2026 – 12:00 PM**  
Engage in real talk about the issues dividing us—and what can unite us.

---

### 🕊 Unity in Action Rally  
🗓 **June 1, 2026 – 1:00 PM**  
Celebrate shared humanity and take a public stand for truth and unity.