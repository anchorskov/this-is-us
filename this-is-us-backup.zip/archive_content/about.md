---
title: "Our Why"
---

## Why We Exist

**This Is Us** is a movement born in Casper, WY from the Integrity Project—a nonpartisan effort to reclaim democracy, restore truth, and unite people across all backgrounds.

### We Oppose:
- Authoritarianism disguised as freedom  
- Billionaire control of discourse  
- Disinformation and manipulation  

### We Support:
- Local voices  
- Shared stories  
- Public truth-telling