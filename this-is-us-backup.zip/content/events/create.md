---
title: "Create Event"
layout: "events-create"
url: "/events/create/"
---

<div id="event-form-ui" class="min-vh-100 flex items-center justify-center"></div>
