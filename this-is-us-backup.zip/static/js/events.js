// Cleaned events.js
import '/js/firebase-config.js'
